export type Priority = 'low' | 'medium' | 'high';
export type Status = 'pending' | 'in-progress' | 'completed';

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  status: Status;
  dueDate: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

export interface TaskStats {
  total: number;
  completed: number;
  pending: number;
  inProgress: number;
  overdue: number;
  byPriority: { low: number; medium: number; high: number };
}

export interface MonitoringData {
  requests: {
    total: number;
    byMethod: Record<string, number>;
    byStatus: Record<string, number>;
    byPath: Record<string, number>;
  };
  latency: {
    p50Ms: number;
    p95Ms: number;
    p99Ms: number;
    avgMs: number;
    sampleCount: number;
  };
  errors: {
    total: number;
    ratePercent: number;
  };
  uptime: {
    seconds: number;
    startTime: string;
  };
  memory: {
    rss: number;
    heapUsed: number;
    heapTotal: number;
  };
}

export interface HealthData {
  status: string;
  timestamp: string;
  version: string;
  uptime: number;
  services: { redis: string };
  environment: string;
}

export type Page = 'dashboard' | 'tasks' | 'monitoring' | 'loadtest' | 'infrastructure' | 'settings';
