import { Request, Response, NextFunction } from 'express';

export class AppError extends Error {
  statusCode: number;
  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
    this.name = 'AppError';
  }
}

export function errorHandler(err: Error, _req: Request, res: Response, _next: NextFunction): void {
  console.error('Error:', err.message);

  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      error: err.message,
      status: err.statusCode,
    });
    return;
  }

  if (err.name === 'SyntaxError') {
    res.status(400).json({ error: 'Invalid JSON in request body', status: 400 });
    return;
  }

  res.status(500).json({
    error: 'Internal server error',
    status: 500,
  });
}
