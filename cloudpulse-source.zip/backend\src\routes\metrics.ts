import { Router, Request, Response } from 'express';
import { metrics } from '../middleware/metrics';

export const metricsRouter = Router();

metricsRouter.get('/metrics', (_req: Request, res: Response) => {
  const uptimeSeconds = (Date.now() - metrics.startTime.getTime()) / 1000;
  const durations = metrics.httpRequestDurationMs;
  
  let p50 = 0, p95 = 0, p99 = 0, avg = 0;
  if (durations.length > 0) {
    const sorted = [...durations].sort((a, b) => a - b);
    p50 = sorted[Math.floor(sorted.length * 0.5)] || 0;
    p95 = sorted[Math.floor(sorted.length * 0.95)] || 0;
    p99 = sorted[Math.floor(sorted.length * 0.99)] || 0;
    avg = durations.reduce((a, b) => a + b, 0) / durations.length;
  }

  let output = '';
  output += '# HELP http_requests_total Total number of HTTP requests\n';
  output += '# TYPE http_requests_total counter\n';
  output += `http_requests_total ${metrics.httpRequestsTotal}\n\n`;

  output += '# HELP http_request_duration_ms HTTP request duration in milliseconds\n';
  output += '# TYPE http_request_duration_ms summary\n';
  output += `http_request_duration_ms{quantile="0.5"} ${p50.toFixed(2)}\n`;
  output += `http_request_duration_ms{quantile="0.95"} ${p95.toFixed(2)}\n`;
  output += `http_request_duration_ms{quantile="0.99"} ${p99.toFixed(2)}\n`;
  output += `http_request_duration_ms_avg ${avg.toFixed(2)}\n\n`;

  for (const [method, count] of Object.entries(metrics.httpRequestsByMethod)) {
    output += `http_requests_by_method{method="${method}"} ${count}\n`;
  }
  output += '\n';

  for (const [status, count] of Object.entries(metrics.httpRequestsByStatus)) {
    output += `http_requests_by_status{status="${status}"} ${count}\n`;
  }
  output += '\n';

  output += `# HELP http_errors_total Total number of HTTP errors (4xx and 5xx)\n`;
  output += `# TYPE http_errors_total counter\n`;
  output += `http_errors_total ${metrics.errorsTotal}\n\n`;

  output += `# HELP process_uptime_seconds Process uptime in seconds\n`;
  output += `# TYPE process_uptime_seconds gauge\n`;
  output += `process_uptime_seconds ${uptimeSeconds.toFixed(0)}\n\n`;

  output += `# HELP nodejs_memory_usage_bytes Process memory usage\n`;
  output += `# TYPE nodejs_memory_usage_bytes gauge\n`;
  const mem = process.memoryUsage();
  output += `nodejs_memory_usage_bytes{type="rss"} ${mem.rss}\n`;
  output += `nodejs_memory_usage_bytes{type="heapTotal"} ${mem.heapTotal}\n`;
  output += `nodejs_memory_usage_bytes{type="heapUsed"} ${mem.heapUsed}\n`;

  res.set('Content-Type', 'text/plain; charset=utf-8');
  res.send(output);
});
